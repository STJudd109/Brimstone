(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var EditableText = Package['babrahams:editable-text'].EditableText;
var sanitizeHtml = Package['djedi:sanitize-html'].sanitizeHtml;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['babrahams:editable-text-wysiwyg-bootstrap-3'] = {};

})();
